// FoodSwift Main Application Logic

// Utility functions
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'error' ? '#ff6b6b' : '#4ecdc4'};
        color: white;
        padding: 1rem 2rem;
        border-radius: 25px;
        font-weight: bold;
        z-index: 1001;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

// Tab switching
function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(tabName).classList.add('active');
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    // Render initial content
    renderRestaurants();
    renderOrders();
    updateCartBadge();
    updateDashboardStats();

    // Set up event listeners
    document.getElementById('profileBtn').addEventListener('click', () => {
        openModal('profileModal');
        showProfilePage();
    });

    document.getElementById('cartBtn').addEventListener('click', () => {
        openModal('cartModal');
        renderCart();
    });

    // Close button listeners
    document.getElementById('closeCart').addEventListener('click', () => closeModal('cartModal'));
    document.getElementById('closeMenu').addEventListener('click', () => closeModal('menuModal'));
    document.getElementById('closeProfile').addEventListener('click', () => closeModal('profileModal'));

    // Checkout button
    document.getElementById('checkoutBtn').addEventListener('click', checkout);

    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Search functionality
    document.getElementById('searchInput').addEventListener('input', (event) => {
        renderRestaurants(event.target.value.toLowerCase());
    });

    // Menu form
    document.getElementById('menuForm').addEventListener('submit', (event) => {
        event.preventDefault();
        const name = document.getElementById('itemName').value;
        const description = document.getElementById('itemDescription').value;
        const price = document.getElementById('itemPrice').value;
        
        const newItem = {
            id: Date.now(),
            name,
            description: description || 'Delicious item from our kitchen',
            price: parseFloat(price)
        };
        
        APP_DATA.restaurants[0].menu.push(newItem);
        document.getElementById('menuForm').reset();
        showNotification('Menu item added successfully!');
    });

    // ESC key to close modals
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeModal('cartModal');
            closeModal('menuModal');
            closeModal('profileModal');
        }
    });
});