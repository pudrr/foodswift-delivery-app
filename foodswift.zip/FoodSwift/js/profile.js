// FoodSwift User Profile Functions

// Profile functions
function showLoginForm() {
    const content = document.getElementById('profileContent');
    content.innerHTML = `
        <h2 style="margin-bottom: 1rem;">Login</h2>
        <form id="loginForm" class="auth-form">
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="loginEmail" required value="demo@foodswift.com">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" id="loginPassword" required value="demo123">
            </div>
            <button type="submit" class="btn-primary">Login</button>
        </form>
        <div class="auth-links">
            Don't have an account? <a onclick="showRegisterForm()">Register</a>
        </div>
    `;

    document.getElementById('loginForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        login(email, password);
    });
}

function showRegisterForm() {
    const content = document.getElementById('profileContent');
    content.innerHTML = `
        <h2 style="margin-bottom: 1rem;">Register</h2>
        <form id="registerForm" class="auth-form">
            <div class="form-group">
                <label>Name</label>
                <input type="text" id="registerName" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="registerEmail" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" id="registerPhone" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" id="registerPassword" required>
            </div>
            <button type="submit" class="btn-primary">Register</button>
        </form>
        <div class="auth-links">
            Already have an account? <a onclick="showLoginForm()">Login</a>
        </div>
    `;

    document.getElementById('registerForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const phone = document.getElementById('registerPhone').value;
        const password = document.getElementById('registerPassword').value;
        register(name, email, phone, password);
    });
}

function showProfilePage() {
    if (!APP_DATA.currentUser) {
        showLoginForm();
        return;
    }

    const user = APP_DATA.currentUser;
    const content = document.getElementById('profileContent');
    content.innerHTML = `
        <div class="user-info">
            <div class="user-avatar">${user.name.charAt(0).toUpperCase()}</div>
            <h2>${user.name}</h2>
            <p style="color: #666;">${user.email}</p>
        </div>
        
        <div style="margin-bottom: 1.5rem;">
            <h3 style="margin-bottom: 0.5rem;">Contact Information</h3>
            <p style="color: #666;">Phone: ${user.phone}</p>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <h3 style="margin-bottom: 0.5rem;">Delivery Addresses</h3>
            ${user.addresses.length === 0 
                ? '<p style="color: #666;">No addresses saved</p>'
                : user.addresses.map(addr => `
                    <div class="address-item ${addr.isDefault ? 'selected' : ''}">
                        <strong>${addr.name}</strong><br>
                        ${addr.address}
                        ${addr.isDefault ? '<br><small style="color: #ff6b6b;">Default</small>' : ''}
                    </div>
                `).join('')
            }
            <button class="btn-secondary" style="margin-top: 0.5rem;" onclick="showAddAddressForm()">Add New Address</button>
        </div>

        <button class="btn-primary" onclick="logout(); closeModal('profileModal');">Logout</button>
    `;
}

function showAddAddressForm() {
    const content = document.getElementById('profileContent');
    content.innerHTML = `
        <h2 style="margin-bottom: 1rem;">Add New Address</h2>
        <form id="addressForm" class="auth-form">
            <div class="form-group">
                <label>Address Name (e.g., Home, Work)</label>
                <input type="text" id="addressName" required>
            </div>
            <div class="form-group">
                <label>Full Address</label>
                <textarea id="addressFull" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn-primary">Save Address</button>
            <button type="button" class="btn-secondary" style="margin-top: 0.5rem;" onclick="showProfilePage()">Cancel</button>
        </form>
    `;

    document.getElementById('addressForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const address = {
            id: Date.now(),
            name: document.getElementById('addressName').value,
            address: document.getElementById('addressFull').value,
            isDefault: APP_DATA.currentUser.addresses.length === 0
        };
        
        APP_DATA.currentUser.addresses.push(address);
        showNotification('Address added successfully!');
        showProfilePage();
    });
}