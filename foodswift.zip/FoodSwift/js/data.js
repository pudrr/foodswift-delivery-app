// FoodSwift Application Data
// Store user data in memory (in real app, this would be in a database)

const APP_DATA = {
    users: [
        {
            id: 1,
            email: 'demo@foodswift.com',
            password: 'demo123',
            name: 'Demo User',
            phone: '+44 7700 900000',
            addresses: [
                { id: 1, name: 'Home', address: '123 Main St, Leeds, LS1 1AA', isDefault: true }
            ]
        }
    ],
    currentUser: null,
    cart: [],
    orders: [],
    restaurants: [
        {
            id: 1,
            name: "Mario's Pizza Palace",
            cuisine: "Italian",
            rating: 4.5,
            deliveryTime: "25-35 min",
            deliveryFee: 2.99,
            menu: [
                { id: 1, name: "Margherita Pizza", description: "Fresh tomato sauce, mozzarella, basil", price: 12.99 },
                { id: 2, name: "Pepperoni Pizza", description: "Tomato sauce, mozzarella, pepperoni", price: 14.99 },
                { id: 3, name: "Caesar Salad", description: "Romaine lettuce, parmesan, croutons", price: 8.99 }
            ]
        },
        {
            id: 2,
            name: "Spice Garden",
            cuisine: "Indian",
            rating: 4.7,
            deliveryTime: "30-40 min",
            deliveryFee: 3.49,
            menu: [
                { id: 4, name: "Chicken Tikka Masala", description: "Tender chicken in creamy tomato sauce", price: 15.99 },
                { id: 5, name: "Vegetable Biryani", description: "Aromatic rice with mixed vegetables", price: 13.99 },
                { id: 6, name: "Garlic Naan", description: "Fresh baked bread with garlic", price: 3.99 }
            ]
        },
        {
            id: 3,
            name: "Dragon Wok",
            cuisine: "Chinese",
            rating: 4.3,
            deliveryTime: "20-30 min",
            deliveryFee: 2.49,
            menu: [
                { id: 7, name: "Sweet & Sour Chicken", description: "Battered chicken with pineapple", price: 14.49 },
                { id: 8, name: "Beef Fried Rice", description: "Wok-fried rice with tender beef", price: 12.99 },
                { id: 9, name: "Spring Rolls", description: "Crispy rolls with vegetable filling", price: 5.99 }
            ]
        },
        {
            id: 4,
            name: "Burger Junction",
            cuisine: "American",
            rating: 4.2,
            deliveryTime: "15-25 min",
            deliveryFee: 1.99,
            menu: [
                { id: 10, name: "Classic Cheeseburger", description: "Beef patty with cheese, lettuce, tomato", price: 9.99 },
                { id: 11, name: "Chicken Wings", description: "Spicy buffalo wings with blue cheese", price: 11.99 },
                { id: 12, name: "Sweet Potato Fries", description: "Crispy sweet potato fries", price: 6.99 }
            ]
        }
    ]
};