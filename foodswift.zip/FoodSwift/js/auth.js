// FoodSwift Authentication Functions

// Authentication functions
function login(email, password) {
    const user = APP_DATA.users.find(u => u.email === email && u.password === password);
    if (user) {
        APP_DATA.currentUser = user;
        updateUIForAuth();
        showNotification('Login successful!');
        closeModal('profileModal');
        return true;
    } else {
        showNotification('Invalid email or password', 'error');
        return false;
    }
}

function register(name, email, phone, password) {
    if (APP_DATA.users.find(u => u.email === email)) {
        showNotification('Email already exists', 'error');
        return false;
    }

    const newUser = {
        id: APP_DATA.users.length + 1,
        name,
        email,
        phone,
        password,
        addresses: []
    };

    APP_DATA.users.push(newUser);
    APP_DATA.currentUser = newUser;
    updateUIForAuth();
    showNotification('Registration successful!');
    closeModal('profileModal');
    return true;
}

function logout() {
    APP_DATA.currentUser = null;
    APP_DATA.cart = [];
    updateUIForAuth();
    updateCartBadge();
    showNotification('Logged out successfully');
}

function updateUIForAuth() {
    const profileBtn = document.getElementById('profileBtn');
    if (APP_DATA.currentUser) {
        profileBtn.textContent = APP_DATA.currentUser.name.charAt(0).toUpperCase();
    } else {
        profileBtn.textContent = '👤';
    }
    renderOrders();
}