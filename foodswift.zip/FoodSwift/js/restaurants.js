// FoodSwift Restaurant Functions

// Restaurant functions
function renderRestaurants(searchTerm = '') {
    const grid = document.getElementById('restaurantGrid');
    const filteredRestaurants = searchTerm
        ? APP_DATA.restaurants.filter(restaurant =>
            restaurant.name.toLowerCase().includes(searchTerm) ||
            restaurant.cuisine.toLowerCase().includes(searchTerm) ||
            restaurant.menu.some(item =>
                item.name.toLowerCase().includes(searchTerm) ||
                item.description.toLowerCase().includes(searchTerm)
            )
        )
        : APP_DATA.restaurants;

    grid.innerHTML = filteredRestaurants.length === 0
        ? '<p style="text-align: center; color: #666; padding: 2rem;">No restaurants found matching your search.</p>'
        : filteredRestaurants.map(restaurant => `
            <div class="restaurant-card" onclick="openMenu(${restaurant.id})">
                <div class="restaurant-image">
                    ${getRestaurantEmoji(restaurant.cuisine)}
                </div>
                <div class="restaurant-info">
                    <div class="restaurant-name">${restaurant.name}</div>
                    <div class="restaurant-details">
                        <span>${restaurant.cuisine} • ${restaurant.deliveryTime}</span>
                        <span class="rating">⭐ ${restaurant.rating}</span>
                    </div>
                </div>
            </div>
        `).join('');
}

function getRestaurantEmoji(cuisine) {
    const emojis = {
        'Italian': '🍕',
        'Indian': '🍛',
        'Chinese': '🥡',
        'American': '🍔'
    };
    return emojis[cuisine] || '🍽️';
}

function openMenu(restaurantId) {
    const restaurant = APP_DATA.restaurants.find(r => r.id === restaurantId);
    document.getElementById('menuTitle').textContent = restaurant.name;
    
    const menuItems = document.getElementById('menuItems');
    menuItems.innerHTML = restaurant.menu.map(item => `
        <div class="menu-item">
            <div class="item-info">
                <div class="item-name">${item.name}</div>
                <div class="item-description">${item.description}</div>
                <div class="item-price">£${item.price.toFixed(2)}</div>
            </div>
            <button class="add-btn" onclick="addToCart(${item.id}, ${restaurantId})">Add</button>
        </div>
    `).join('');

    openModal('menuModal');
}