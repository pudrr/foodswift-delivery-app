// FoodSwift Shopping Cart Functions

// Cart functions
function addToCart(itemId, restaurantId) {
    if (!APP_DATA.currentUser) {
        showNotification('Please login to add items to cart', 'error');
        openModal('profileModal');
        showLoginForm();
        return;
    }

    const restaurant = APP_DATA.restaurants.find(r => r.id === restaurantId);
    const item = restaurant.menu.find(i => i.id === itemId);
    
    const existingItem = APP_DATA.cart.find(i => i.id === itemId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        APP_DATA.cart.push({
            ...item,
            quantity: 1,
            restaurantId: restaurantId,
            restaurantName: restaurant.name
        });
    }
    
    updateCartBadge();
    showNotification('Item added to cart!');
}

function updateCartBadge() {
    const badge = document.getElementById('cartBtn');
    const count = APP_DATA.cart.reduce((sum, item) => sum + item.quantity, 0);
    badge.setAttribute('data-count', count);
}

function renderCart() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');

    if (APP_DATA.cart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; color: #666;">Your cart is empty</p>';
        cartTotal.textContent = '';
    } else {
        cartItems.innerHTML = APP_DATA.cart.map(item => `
            <div class="cart-item">
                <div class="item-info">
                    <div class="item-name">${item.name}</div>
                    <div class="item-price">£${item.price.toFixed(2)} each</div>
                </div>
                <div class="quantity-controls">
                    <button class="qty-btn" onclick="updateCartQuantity(${item.id}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button class="qty-btn" onclick="updateCartQuantity(${item.id}, 1)">+</button>
                </div>
            </div>
        `).join('');

        const total = APP_DATA.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        cartTotal.textContent = `Total: £${total.toFixed(2)}`;
    }
}

function updateCartQuantity(itemId, change) {
    const item = APP_DATA.cart.find(i => i.id === itemId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            APP_DATA.cart = APP_DATA.cart.filter(i => i.id !== itemId);
        }
        updateCartBadge();
        renderCart();
    }
}

function checkout() {
    if (APP_DATA.cart.length === 0) return;

    if (!APP_DATA.currentUser) {
        showNotification('Please login to place an order', 'error');
        return;
    }

    if (APP_DATA.currentUser.addresses.length === 0) {
        showNotification('Please add a delivery address first', 'error');
        closeModal('cartModal');
        openModal('profileModal');
        showProfilePage();
        return;
    }

    const total = APP_DATA.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const newOrder = {
        id: APP_DATA.orders.length + 1,
        userId: APP_DATA.currentUser.id,
        restaurant: APP_DATA.cart[0].restaurantName,
        items: APP_DATA.cart.map(item => ({
            name: item.name,
            quantity: item.quantity,
            price: item.price
        })),
        total: total,
        status: "preparing",
        date: new Date().toISOString().split('T')[0],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    APP_DATA.orders.unshift(newOrder);
    APP_DATA.cart = [];
    updateCartBadge();
    closeModal('cartModal');
    showNotification('Order placed successfully!');
    switchTab('orders');
    updateDashboardStats();
}