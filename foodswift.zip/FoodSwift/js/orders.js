// FoodSwift Order Management Functions

// Order functions
function renderOrders() {
    const ordersList = document.getElementById('ordersList');
    
    if (!APP_DATA.currentUser) {
        ordersList.innerHTML = '<p style="text-align: center; color: #666;">Please login to view your orders</p>';
        return;
    }

    const userOrders = APP_DATA.orders.filter(o => o.userId === APP_DATA.currentUser.id);
    
    if (userOrders.length === 0) {
        ordersList.innerHTML = '<p style="text-align: center; color: #666;">No orders yet</p>';
    } else {
        ordersList.innerHTML = userOrders.map(order => `
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <div style="font-weight: bold;">${order.restaurant}</div>
                        <div style="color: #666; font-size: 0.9rem;">${order.date} at ${order.time}</div>
                    </div>
                    <div class="order-status ${getStatusClass(order.status)}">${formatStatus(order.status)}</div>
                </div>
                <div style="margin-bottom: 1rem;">
                    ${order.items.map(item => `
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span>${item.quantity}x ${item.name}</span>
                            <span>£${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                    `).join('')}
                </div>
                <div style="border-top: 1px solid #eee; padding-top: 1rem; font-weight: bold; text-align: right;">
                    Total: £${order.total.toFixed(2)}
                </div>
            </div>
        `).join('');
    }

    renderRestaurantOrders();
}

function renderRestaurantOrders() {
    const restaurantOrders = document.getElementById('restaurantOrders');
    const recentOrders = APP_DATA.orders.slice(0, 5);

    if (recentOrders.length === 0) {
        restaurantOrders.innerHTML = '<p style="text-align: center; color: #666;">No recent orders</p>';
    } else {
        restaurantOrders.innerHTML = recentOrders.map(order => `
            <div class="order-card" style="margin-bottom: 1rem;">
                <div class="order-header">
                    <div>
                        <div style="font-weight: bold;">Order #${order.id.toString().padStart(3, '0')}</div>
                        <div style="color: #666; font-size: 0.9rem;">${order.date} at ${order.time}</div>
                    </div>
                    <div class="order-status ${getStatusClass(order.status)}">${formatStatus(order.status)}</div>
                </div>
                <div>
                    ${order.items.map(item => `${item.quantity}x ${item.name}`).join(', ')}
                </div>
                <div style="margin-top: 0.5rem; font-weight: bold;">£${order.total.toFixed(2)}</div>
            </div>
        `).join('');
    }
}

function getStatusClass(status) {
    const classes = {
        'preparing': 'status-preparing',
        'on-way': 'status-on-way',
        'delivered': 'status-delivered'
    };
    return classes[status] || '';
}

function formatStatus(status) {
    const statusMap = {
        'preparing': 'Preparing',
        'on-way': 'On the Way',
        'delivered': 'Delivered'
    };
    return statusMap[status] || status;
}

// Dashboard functions
function updateDashboardStats() {
    const today = new Date().toISOString().split('T')[0];
    const todayOrders = APP_DATA.orders.filter(o => o.date === today);
    const todayRevenue = todayOrders.reduce((sum, order) => sum + order.total, 0);
    
    document.getElementById('todayOrders').textContent = todayOrders.length;
    document.getElementById('todayRevenue').textContent = `£${todayRevenue.toFixed(2)}`;
}